# Shrimp&Snail > shrimp-snail annotated images ver1
https://universe.roboflow.com/shrimpandsnail/shrimp-snail

Provided by a Roboflow user
License: CC BY 4.0

