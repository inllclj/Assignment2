# Shrimp&Snail > shrimp-snail dataset ver2
https://universe.roboflow.com/shrimpandsnail/shrimp-snail

Provided by a Roboflow user
License: CC BY 4.0

